(function ($) {
    $.url = {
        company: "digital",
        //生产 www.isgo.com
        webUrl: "http://49.232.47.138:8080/shopping/",
        locationUrl: "http://49.232.47.138:8080/shopping/",
        webUrlB: "http://49.232.47.138:8080/shopping/"

        //生产 private.isgo.com
        //webUrl: "http://private.isgo.com/ISGOC1/",
        //locationUrl: "http://private.isgo.com/ISGOC1/web/Sale/",
        //webUrlB: "http://private.isgo.com/ISGOC1/"
            };
})(jQuery);